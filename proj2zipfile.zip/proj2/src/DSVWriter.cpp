#include "DSVWriter.h"
#include "DataSink.h"

struct CDSVWriter::SImplementation {
    std::shared_ptr<CDataSink> sink;
    char delimiter;
    bool quoteall;

    SImplementation(std::shared_ptr<CDataSink> sink, char delimiter, bool quoteall): sink(sink), delimiter(delimiter), quoteall(quoteall) {
    }

    bool WriteRow(const std::vector<std::string> &row){
        return true;
    }

};

CDSVWriter::CDSVWriter(std::shared_ptr<CDataSink> sink, char delimiter, bool quoteall) : DImplementation(std::make_unique<SImplementation>(sink, delimiter, quoteall)) {
}

CDSVWriter::~CDSVWriter() = default;

bool CDSVWriter::WriteRow(const std::vector<std::string> &row){
    return DImplementation->WriteRow(row);
}

