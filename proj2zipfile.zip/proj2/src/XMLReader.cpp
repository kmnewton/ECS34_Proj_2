#include "XMLReader.h"
#include <expat.h>
#include <vector>
#include <memory>
#include <queue>

struct CXMLReader::SImplementation {

};

CXMLReader::CXMLReader(std::shared_ptr<CDataSource> src) : DImplementation(std::make_unique<SImplementation>(std::move(src))) {

}

CXMLReader::~CXMLReader() = default;

bool CXMLReader::End() const {
    return 0;
}

bool CXMLReader::ReadEntity(SXMLEntity& entity, bool skipCharData) {
    return 0;
}
