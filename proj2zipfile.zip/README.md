# ECS34_Proj_2

https://www.geeksforgeeks.org/std-string-replace-in-cpp/
https://www.geeksforgeeks.org/string-find-in-cpp/
https://www.geeksforgeeks.org/vector-of-strings-in-cpp/
https://makefiletutorial.com/

I used the Course Assist AI to help understand how to make a makefile. 
